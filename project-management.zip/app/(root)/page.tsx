"use client"
import React, { useState } from "react";
import { Eye, EyeOff, Zap, ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

interface AuthProps {
  mode: "login" | "register";
  onSwitch: () => void;
  onSuccess: () => void;
}

const FEATURES = [
  "Kanban boards with drag & drop",
  "Real-time team collaboration",
  "Advanced analytics & reporting",
  "Custom workflows & automation",
  "Role-based access control",
];

export function AuthPage({ mode, onSwitch, onSuccess }: AuthProps) {
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "alex@projectflow.io", password: "password123", confirmPassword: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); onSuccess(); }, 800);
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left Panel — Form */}
      <div className="flex-1 flex flex-col justify-center items-center px-6 py-10 lg:max-w-[480px]">
        {/* Logo */}
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2 mb-8">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Zap size={16} className="text-white" />
            </div>
            <span className="font-bold text-foreground tracking-tight">ProjectFlow</span>
          </div>

          <h1 className="font-bold text-foreground mb-1">
            {mode === "login" ? "Welcome back" : "Create your account"}
          </h1>
          <p className="text-sm text-muted-foreground mb-6">
            {mode === "login"
              ? "Enter your credentials to access your workspace."
              : "Join thousands of teams using ProjectFlow."}
          </p>

          {/* Social login */}
          <div className="grid grid-cols-2 gap-2 mb-5">
            {["Google", "GitHub"].map(provider => (
              <button
                key={provider}
                className="h-9 flex items-center justify-center gap-2 border border-border rounded-md text-sm text-foreground hover:bg-muted transition-colors font-medium"
              >
                <span className="w-4 h-4 rounded-full bg-muted-foreground/20" />
                {provider}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 mb-5">
            <div className="flex-1 h-px bg-border" />
            <span className="text-xs text-muted-foreground">or continue with email</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {mode === "register" && (
              <Input
                label="Full name"
                placeholder="Alex Rivera"
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                required
              />
            )}
            <Input
              label="Email address"
              type="email"
              placeholder="alex@company.com"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              required
            />
            <div className="flex flex-col gap-1">
              <label className="text-xs font-medium text-foreground">Password</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  placeholder="Enter your password"
                  required
                  className="w-full h-8 bg-input-background border border-border rounded-md px-3 pr-9 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            {mode === "register" && (
              <Input
                label="Confirm password"
                type="password"
                placeholder="Re-enter your password"
                value={form.confirmPassword}
                onChange={e => setForm({ ...form, confirmPassword: e.target.value })}
                required
              />
            )}

            {mode === "login" && (
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input type="checkbox" className="w-3.5 h-3.5 rounded border-border" />
                  <span className="text-xs text-muted-foreground">Remember me</span>
                </label>
                <button type="button" className="text-xs text-primary hover:underline">Forgot password?</button>
              </div>
            )}

            <Button type="submit" variant="primary" size="md" loading={loading} className="w-full mt-1">
              {mode === "login" ? "Sign in" : "Create account"}
              {!loading && <ArrowRight size={14} />}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground text-center mt-5">
            {mode === "login" ? "Don't have an account? " : "Already have an account? "}
            <button onClick={onSwitch} className="text-primary hover:underline font-medium">
              {mode === "login" ? "Sign up free" : "Sign in"}
            </button>
          </p>

          {mode === "register" && (
            <p className="text-xs text-muted-foreground text-center mt-3">
              By creating an account, you agree to our{" "}
              <span className="text-primary hover:underline cursor-pointer">Terms of Service</span>
              {" "}and{" "}
              <span className="text-primary hover:underline cursor-pointer">Privacy Policy</span>.
            </p>
          )}
        </div>
      </div>

      {/* Right Panel — Illustration */}
      <div className="hidden lg:flex flex-1 bg-primary relative overflow-hidden flex-col justify-center items-center px-12 py-10">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-white/5" />
          <div className="absolute -bottom-20 -left-20 w-96 h-96 rounded-full bg-white/5" />
          <div className="absolute top-1/2 left-1/4 w-48 h-48 rounded-full bg-white/5" />
        </div>

        <div className="relative z-10 max-w-sm">
          <div className="text-white mb-6">
            <div className="text-xs font-semibold uppercase tracking-widest text-white/60 mb-2">Why ProjectFlow?</div>
            <h2 className="font-bold text-white mb-3">Manage projects like a pro team</h2>
            <p className="text-sm text-white/70 leading-relaxed">
              Bring your team together with powerful tools for planning, tracking, and shipping — built for modern teams.
            </p>
          </div>

          <div className="space-y-2.5">
            {FEATURES.map(f => (
              <div key={f} className="flex items-center gap-2.5">
                <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                  <Check size={11} className="text-white" />
                </div>
                <span className="text-sm text-white/80">{f}</span>
              </div>
            ))}
          </div>

          {/* Mock card */}
          <div className="mt-8 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-md bg-white/20 flex items-center justify-center">
                <Zap size={12} className="text-white" />
              </div>
              <span className="text-sm font-semibold text-white">ProjectFlow v2.0</span>
              <span className="ml-auto text-xs text-white/60">68%</span>
            </div>
            <div className="h-1.5 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full w-[68%] bg-white rounded-full" />
            </div>
            <div className="flex items-center gap-1.5 mt-3">
              {["AR", "SC", "MJ"].map(initials => (
                <div key={initials} className="w-6 h-6 rounded-full bg-white/20 border-2 border-primary flex items-center justify-center text-white text-xs font-semibold" style={{ marginLeft: "-4px" }}>
                  {initials[0]}
                </div>
              ))}
              <span className="text-xs text-white/60 ml-1.5">+2 members</span>
              <span className="ml-auto text-xs text-white/60">Due Jul 15</span>
            </div>
          </div>

          <p className="text-xs text-white/40 mt-6 text-center">Trusted by 10,000+ teams worldwide</p>
        </div>
      </div>
    </div>
  );
}
