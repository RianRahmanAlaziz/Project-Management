import type { WorkspaceColor } from "../types/settings";

export const COLORS: WorkspaceColor[] = [
    {
        label: "Indigo",
        bg: "bg-indigo-500",
        ring: "ring-indigo-500",
    },
    {
        label: "Violet",
        bg: "bg-violet-500",
        ring: "ring-violet-500",
    },
    {
        label: "Blue",
        bg: "bg-blue-500",
        ring: "ring-blue-500",
    },
    {
        label: "Emerald",
        bg: "bg-emerald-500",
        ring: "ring-emerald-500",
    },
    {
        label: "Rose",
        bg: "bg-rose-500",
        ring: "ring-rose-500",
    },
    {
        label: "Amber",
        bg: "bg-amber-500",
        ring: "ring-amber-500",
    },
];


import {
    Building2,
    Bell,
    Shield,
    Trash2,
} from "lucide-react";

export const WORKSPACE_SETTINGS = [
    {
        id: "general",
        label: "General",
        icon: Building2,
    },
    {
        id: "security",
        label: "Security",
        icon: Shield,
    },
    {
        id: "notifications",
        label: "Notifications",
        icon: Bell,
    },
    {
        id: "danger",
        label: "Danger Zone",
        icon: Trash2,
        danger: true,
    },
];