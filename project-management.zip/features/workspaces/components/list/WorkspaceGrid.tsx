import { Briefcase, Plus } from "lucide-react";

import {
    Button,
    EmptyState,
} from "@/components/ui";

import type { Workspace } from "../../types/workspace";

import {
    WorkspaceCard,
} from "@/features/workspaces/components";

interface WorkspaceGridProps {
    workspaces: Workspace[];
    onOpenWorkspace: (workspace: Workspace) => void;
    onOpenProjects: (workspace: Workspace) => void;
    onOpenMembers: (workspace: Workspace) => void;
    onOpenSetting: (workspace: Workspace) => void;
    OpenCreateWorkspace: () => void;
}

export default function WorkspaceGrid({
    workspaces,
    onOpenWorkspace,
    onOpenProjects,
    onOpenMembers,
    onOpenSetting,
    OpenCreateWorkspace,
}: WorkspaceGridProps) {
    if (workspaces.length === 0) {
        return (
            <div className="rounded-2xl border border-border bg-card shadow-xl">
                <EmptyState
                    icon={<Briefcase size={22} />}
                    title="No workspaces found"
                    description="No workspace matches your search. Create a new workspace to start organizing your projects."
                    action={
                        <Button
                            type="button"
                            size="lg"
                            variant="primary"
                            onClick={OpenCreateWorkspace}
                        >
                            <Plus size={16} />
                            New Workspace
                        </Button>
                    }
                />
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
            {workspaces.map((workspace) => (
                <WorkspaceCard
                    key={workspace.id}
                    workspace={workspace}
                    onOpenWorkspace={onOpenWorkspace}
                    onOpenProjects={onOpenProjects}
                    onOpenMembers={onOpenMembers}
                    onOpenSetting={onOpenSetting}
                />
            ))}
        </div>
    );
}