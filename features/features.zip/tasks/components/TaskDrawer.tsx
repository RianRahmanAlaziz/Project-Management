import { useState } from "react";

import {
    USERS,
    TASKS,
    PROJECTS,
    CHART_DATA,
} from "@/data/data";
import TaskHeader from "./TaskHeader";
import TaskContent from "./TaskContent";
import TaskCommentInput from "./TaskCommentInput";


const priorityColors: Record<string, string> = {
    High: "text-destructive bg-red-50 dark:bg-red-950/30",
    Medium: "text-warning bg-amber-50 dark:bg-amber-950/30",
    Low: "text-muted-foreground bg-muted",
};


export default function TaskDrawer({ taskId, onClose }) {

    const task = TASKS.find((t) => t.id === taskId);
    const [activeTab, setActiveTab] = useState("Comments");
    const [comment, setComment] = useState("");
    const [status, setStatus] = useState(task?.column ?? "Todo");
    const [priority, setPriority] = useState(task?.priority ?? "Medium");


    if (!task) return null;

    const assignee = USERS.find(
        (user) => user.id === task.assignee
    );

    return (
        <div className="fixed inset-0 z-40 flex">
            <div className="flex-1 bg-black/30 backdrop-blur-sm" onClick={onClose} />
            <div className="w-full max-w-[520px] bg-card border-l border-border flex flex-col h-full shadow-2xl overflow-hidden">
                <TaskHeader
                    tasks={task}
                    status={status}
                    onClose={onClose}
                />

                <TaskContent
                    task={task}
                    assignee={assignee}
                    status={status}
                    priority={priority}
                    setStatus={setStatus}
                    setPriority={setPriority}
                    activeTab={activeTab}
                    setActiveTab={setActiveTab}
                />

                {activeTab === "Comments" && (
                    <TaskCommentInput
                        comment={comment}
                        setComment={setComment}
                    />
                )}

            </div>
        </div>
    )
}
