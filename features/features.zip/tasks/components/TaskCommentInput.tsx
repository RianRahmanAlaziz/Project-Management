"use client";

import { AtSign, Paperclip, Send, Smile } from "lucide-react";

import { Avatar, Button } from "@/components/ui";

interface TaskCommentInputProps {
    comment: string;
    setComment: React.Dispatch<React.SetStateAction<string>>;
}

export default function TaskCommentInput({
    comment,
    setComment,
}: TaskCommentInputProps) {
    return (
        <div className="flex-shrink-0 border-t border-border p-4">
            <div className="flex gap-2.5">
                <Avatar name="Alex Rivera" size="sm" />
                <div className="flex-1 border border-border rounded-lg overflow-hidden focus-within:ring-1 focus-within:ring-ring">
                    <textarea
                        value={comment}
                        onChange={e => setComment(e.target.value)}
                        placeholder="Write a comment... @mention someone"
                        className="w-full bg-transparent px-3 pt-2.5 pb-1 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none resize-none"
                        rows={2}
                    />
                    <div className="flex items-center justify-between px-2 py-1.5 border-t border-border bg-muted/30">
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                            <button className="p-0.5 hover:text-foreground transition-colors"><Smile size={13} /></button>
                            <button className="p-0.5 hover:text-foreground transition-colors"><AtSign size={13} /></button>
                            <button className="p-0.5 hover:text-foreground transition-colors"><Paperclip size={13} /></button>
                        </div>
                        <Button size="xs" variant="primary" disabled={!comment.trim()}>
                            <Send size={11} />
                            Send
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}
